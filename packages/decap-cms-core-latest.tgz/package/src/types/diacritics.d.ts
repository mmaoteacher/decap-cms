declare module 'diacritics';
